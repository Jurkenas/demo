# Person Management API

This project provides a RESTful API for managing person entities. It includes endpoints to create, read, update, and delete person records.

## Table of Contents
- [Technologies](#technologies)
- [Requirements](#requirements)
- [Setup](#setup)
- [Endpoints](#endpoints)
- [Configuration](#configuration)

## Technologies

- **Java 17**
- **Spring Boot**
- **Gradle**
- **H2 Database** (for in-memory storage during development)

## Requirements

- JDK 17
- Gradle 7.x (or compatible version)

## Setup

1. Clone the repository to your local machine.
2. Navigate to the project directory.
3. Build the project using Gradle:

   ```bash
   ./gradlew build
   ```

4. Run the application:

   ```bash
   ./gradlew bootRun
   ```

5. Access the H2 database console at `http://localhost:8080/h2-console`.

## Endpoints

### Create a Person

- **POST** `/persons`

  Request Body:
  ```json
  {
    "name": "John",
    "surname": "Doe",
    "address": "123 Main St"
  }
  ```

### Get a Person by ID

- **GET** `/persons/{id}`

### Get All Persons

- **GET** `/persons`

### Update a Person

- **PUT** `/persons/{id}`

  Request Body:
  ```json
  {
    "name": "John Updated",
    "surname": "Doe Updated",
    "address": "456 Main St"
  }
  ```

### Patch a Person

- **PATCH** `/persons/{id}`

  Request Body:
  ```json
  {
    "name": "New Name"
  }
  ```

### Delete a Person

- **DELETE** `/persons/{id}`

## Configuration

To configure the H2 database and enable the console, add the following properties to your `application.properties` file:

```properties
spring.h2.console.enabled=true
spring.datasource.url=jdbc:h2:mem:testdb
spring.datasource.driverClassName=org.h2.Driver
spring.datasource.username=username
spring.datasource.password=password
```

Make sure to replace the database URL, username, and password with your desired configuration.