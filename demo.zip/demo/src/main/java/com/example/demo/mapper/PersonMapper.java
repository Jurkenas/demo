package com.example.demo.mapper;

import com.example.demo.dto.CreatePersonRequestDTO;
import com.example.demo.dto.PersonResponseDTO;
import com.example.demo.entity.PersonEntity;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class PersonMapper {

    public PersonEntity toEntity(CreatePersonRequestDTO dto) {
        if (dto == null) {
            return null;
        }

        PersonEntity person = new PersonEntity();
        person.setName(dto.getName());
        person.setSurname(dto.getSurname());
        person.setAddress(dto.getAddress());
        return person;
    }

    public PersonResponseDTO toDTO(PersonEntity entity) {
        if (entity == null) {
            return null;
        }

        PersonResponseDTO dto = new PersonResponseDTO();
        dto.setId(entity.getId());
        dto.setName(entity.getName());
        dto.setSurname(entity.getSurname());
        dto.setAddress(entity.getAddress());
        return dto;
    }

    public List<PersonResponseDTO> toDTOList(List<PersonEntity> personEntities) {
        return personEntities.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }
}
