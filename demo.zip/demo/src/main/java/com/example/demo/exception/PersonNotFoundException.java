package com.example.demo.exception;

public class PersonNotFoundException extends RuntimeException {
    public PersonNotFoundException(String criteria) {
        super("Person not found by " + criteria);
    }
}
