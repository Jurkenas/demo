package com.example.demo.service;

import com.example.demo.dto.CreatePersonRequestDTO;
import com.example.demo.dto.PersonResponseDTO;
import com.example.demo.entity.PersonEntity;
import com.example.demo.exception.PersonNotFoundException;
import com.example.demo.mapper.PersonMapper;
import com.example.demo.repository.PersonRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Service
public class PersonService {

    private final PersonRepository personRepository;
    private final PersonMapper personMapper;

    public void createPerson(CreatePersonRequestDTO request) {
        PersonEntity personEntity = personMapper.toEntity(request);
        personRepository.save(personEntity);
    }

    public List<PersonResponseDTO> getAllPersons() {
        List<PersonEntity> entities = personRepository.findAll();
        return personMapper.toDTOList(entities);
    }

    public void updatePerson(Long id, CreatePersonRequestDTO request) {
        PersonEntity person = personRepository.findById(id)
                .orElseThrow(() -> new PersonNotFoundException("id " + id));

        person.setName(request.getName());
        person.setSurname(request.getSurname());
        person.setAddress(request.getAddress());

        personRepository.save(person);
    }

    public void patchPerson(Long id, Map<String, Object> updates) {
        PersonEntity person = personRepository.findById(id)
                .orElseThrow(() -> new PersonNotFoundException("id " + id));

        updates.forEach((key, value) -> {
            switch (key) {
                case "name" -> person.setName((String) value);
                case "surname" -> person.setSurname((String) value);
                case "address" -> person.setAddress((String) value);
                default -> throw new IllegalArgumentException("Invalid field: " + key);
            }
        });

        personRepository.save(person);
    }

    public void deletePerson(Long id) {
        if (!personRepository.existsById(id)) {
            throw new PersonNotFoundException("id " + id);
        }
        personRepository.deleteById(id);
    }


    public PersonResponseDTO getPersonById(Long id) {
        PersonEntity personEntity = personRepository.findById(id)
                .orElseThrow(() -> new PersonNotFoundException("id " + id));
        return personMapper.toDTO(personEntity);
    }
}
